# Binance Futures Bot (src)

This directory contains the bot source code for Binance USDT-M Futures.

## Requirements
- Python 3.8+
- pip packages:
  - python-binance
  - numpy

Install:
```bash
pip install python-binance numpy
